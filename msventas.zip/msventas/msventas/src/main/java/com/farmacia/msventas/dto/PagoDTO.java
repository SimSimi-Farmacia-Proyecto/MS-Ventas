package com.farmacia.msventas.dto;
import lombok.Data;

@Data
public class PagoDTO {
    private Long ventaId;
    private Double monto;
    private String metodo;

}
