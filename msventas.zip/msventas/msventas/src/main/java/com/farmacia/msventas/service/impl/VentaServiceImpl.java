package com.farmacia.msventas.service.impl;
import com.farmacia.msventas.dto.*;
import com.farmacia.msventas.exception.VentaException;
import com.farmacia.msventas.model.EstadoVenta;
import com.farmacia.msventas.model.Venta;
import com.farmacia.msventas.repository.VentaRepository;
import com.farmacia.msventas.service.VentaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

@Service
@RequiredArgsConstructor
@Transactional
public class VentaServiceImpl implements VentaService {
    private final VentaRepository ventaRepository;
    private final RestTemplate restTemplate;

    private final String URL_INVENTARIO =
            "http://localhost:8085/api/inventario/descontar";

    private final String URL_RECETAS =
            "http://localhost:8084/api/recetas/validar";

    private final String URL_DETALLE =
            "http://localhost:8083/api/detalle-venta/lote";

    private final String URL_PAGOS =
            "http://localhost:8086/api/pagos";

    private final String URL_NOTIFICACIONES =
            "http://localhost:8087/api/notificaciones";

    @Override
    public VentaResponseDTO realizarVenta(
            VentaRequestDTO dto
    ) {

        Venta venta = Venta.builder()
                .clienteId(dto.getClienteId())
                .total(0.0)
                .estado(EstadoVenta.PENDIENTE)
                .build();

        venta = ventaRepository.save(venta);

        double total = 0;

        for (DetalleVentaDTO detalle
                : dto.getDetalles()) {

            if (Boolean.TRUE.equals(
                    detalle.getRequiereReceta()
            )) {

                RecetaDTO recetaDTO =
                        new RecetaDTO();

                recetaDTO.setClienteId(
                        dto.getClienteId()
                );

                Boolean valida =
                        restTemplate.postForObject(
                                URL_RECETAS,
                                recetaDTO,
                                Boolean.class
                        );

                if (!Boolean.TRUE.equals(valida)) {

                    throw new VentaException(
                            "El cliente no posee una receta válida"
                    );
                }
            }

            StockDTO stockDTO =
                    new StockDTO();

            stockDTO.setMedicamentoId(
                    detalle.getMedicamentoId()
            );

            stockDTO.setCantidad(
                    detalle.getCantidad()
            );

            restTemplate.postForObject(
                    URL_INVENTARIO,
                    stockDTO,
                    Void.class
            );

            total += detalle.getCantidad()
                    * detalle.getPrecioUnitario();
        }

        Venta finalVenta = venta;
        dto.getDetalles()
                .forEach(d ->
                        d.setVentaId(finalVenta.getId())
                );

        restTemplate.postForObject(
                URL_DETALLE,
                dto.getDetalles(),
                Void.class
        );

        PagoDTO pago =
                new PagoDTO();

        pago.setVentaId(venta.getId());
        pago.setMonto(total);
        pago.setMetodo("EFECTIVO");

        restTemplate.postForObject(
                URL_PAGOS,
                pago,
                Void.class
        );

        venta.setTotal(total);
        venta.setEstado(EstadoVenta.PAGADA);

        Venta guardada =
                ventaRepository.save(venta);

        NotificacionDTO notif =
                new NotificacionDTO();

        notif.setMensaje(
                "Venta realizada correctamente. ID: "
                        + guardada.getId()
        );

        restTemplate.postForObject(
                URL_NOTIFICACIONES,
                notif,
                Void.class
        );

        return convertirDTO(guardada);
    }

    // =========================
    // MAPPER MANUAL
    // =========================

    private VentaResponseDTO convertirDTO(
            Venta venta
    ) {

        VentaResponseDTO dto =
                new VentaResponseDTO();

        dto.setId(venta.getId());
        dto.setClienteId(venta.getClienteId());
        dto.setFecha(venta.getFecha());
        dto.setTotal(venta.getTotal());
        dto.setEstado(venta.getEstado());

        return dto;
    }
}
